/**
 * 墨羽书画AI探索营小程序工具函数
 */

/**
 * 格式化时间
 * @param {Date} date 日期对象
 * @returns {string} 格式化后的时间字符串，格式为：YYYY-MM-DD HH:mm:ss
 */
const formatTime = date => {
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const hour = date.getHours();
  const minute = date.getMinutes();
  const second = date.getSeconds();

  return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':');
};

/**
 * 格式化数字
 * @param {number} n 数字
 * @returns {string} 格式化后的数字字符串，小于10的数字前面补0
 */
const formatNumber = n => {
  n = n.toString();
  return n[1] ? n : '0' + n;
};

/**
 * 显示提示信息
 * @param {string} message 提示信息
 * @param {string} type 提示类型，可选值：success, error, loading, none
 * @param {number} duration 提示显示时间，单位毫秒，默认1500
 */
const showToast = (message, type = 'none', duration = 1500) => {
  wx.showToast({
    title: message,
    icon: type,
    duration: duration
  });
};

/**
 * 显示加载中
 * @param {string} message 加载提示文字，默认为"加载中..."
 */
const showLoading = (message = '加载中...') => {
  wx.showLoading({
    title: message,
    mask: true
  });
};

/**
 * 隐藏加载中
 */
const hideLoading = () => {
  wx.hideLoading();
};

/**
 * 显示确认对话框
 * @param {string} title 标题
 * @param {string} content 内容
 * @param {boolean} showCancel 是否显示取消按钮，默认为true
 * @param {function} confirmCallback 确认按钮回调函数
 * @param {function} cancelCallback 取消按钮回调函数
 */
const showModal = (title, content, showCancel = true, confirmCallback, cancelCallback) => {
  wx.showModal({
    title,
    content,
    showCancel,
    success: res => {
      if (res.confirm && typeof confirmCallback === 'function') {
        confirmCallback();
      } else if (res.cancel && typeof cancelCallback === 'function') {
        cancelCallback();
      }
    }
  });
};

/**
 * 获取当前页面路径
 * @returns {string} 当前页面路径
 */
const getCurrentPageUrl = () => {
  const pages = getCurrentPages();
  const currentPage = pages[pages.length - 1];
  return currentPage.route;
};

/**
 * 深拷贝对象
 * @param {Object} obj 需要拷贝的对象
 * @returns {Object} 拷贝后的新对象
 */
const deepClone = obj => {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  
  let clone = Array.isArray(obj) ? [] : {};
  
  for (let key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      clone[key] = deepClone(obj[key]);
    }
  }
  
  return clone;
};

/**
 * 防抖函数
 * @param {function} func 要执行的函数
 * @param {number} wait 等待时间，单位毫秒
 * @returns {function} 防抖处理后的函数
 */
const debounce = (func, wait = 300) => {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      func.apply(this, args);
    }, wait);
  };
};

/**
 * 节流函数
 * @param {function} func 要执行的函数
 * @param {number} limit 时间限制，单位毫秒
 * @returns {function} 节流处理后的函数
 */
const throttle = (func, limit = 300) => {
  let inThrottle;
  return function(...args) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => {
        inThrottle = false;
      }, limit);
    }
  };
};

/**
 * 随机生成指定范围内的整数
 * @param {number} min 最小值
 * @param {number} max 最大值
 * @returns {number} 随机整数
 */
const randomInteger = (min, max) => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

/**
 * 检查是否为空对象
 * @param {Object} obj 需要检查的对象
 * @returns {boolean} 是否为空对象
 */
const isEmptyObject = obj => {
  return Object.keys(obj).length === 0;
};

/**
 * 将对象转换为查询字符串
 * @param {Object} obj 需要转换的对象
 * @returns {string} 查询字符串
 */
const objectToQueryString = obj => {
  return Object.keys(obj)
    .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(obj[key]))
    .join('&');
};

/**
 * 从查询字符串解析参数
 * @param {string} queryString 查询字符串
 * @returns {Object} 解析后的参数对象
 */
const parseQueryString = queryString => {
  const params = {};
  const queries = queryString.split('&');
  
  queries.forEach(query => {
    const [key, value] = query.split('=');
    params[decodeURIComponent(key)] = decodeURIComponent(value || '');
  });
  
  return params;
};

/**
 * 生成UUID
 * @returns {string} UUID
 */
const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

module.exports = {
  formatTime,
  formatNumber,
  showToast,
  showLoading,
  hideLoading,
  showModal,
  getCurrentPageUrl,
  deepClone,
  debounce,
  throttle,
  randomInteger,
  isEmptyObject,
  objectToQueryString,
  parseQueryString,
  generateUUID
};