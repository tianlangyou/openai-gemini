// app.js - 应用程序逻辑
// app.js - 应用程序逻辑
App({
  onLaunch() {
    // 使用新的API获取系统信息
    const deviceInfo = wx.getDeviceInfo();
    const windowInfo = wx.getWindowInfo();
    const appBaseInfo = wx.getAppBaseInfo();
    
    // 将信息合并到全局数据中
    this.globalData.deviceInfo = deviceInfo;
    this.globalData.windowInfo = windowInfo;
    this.globalData.appBaseInfo = appBaseInfo;

    // 检查用户是否之前已登录
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.globalData.userInfo = userInfo;
      this.globalData.hasUserInfo = true;
    }
  },
  
  onShow() {
    // 应用展示给用户时执行
  },
  
  onHide() {
    // 应用隐藏时执行
  },
  
  globalData: {
    userInfo: null,
    hasUserInfo: false,
    deviceInfo: null,
    windowInfo: null,
    appBaseInfo: null,
    apiBaseUrl: 'https://api.yourserver.com', // 替换为您的实际API URL
  }
});