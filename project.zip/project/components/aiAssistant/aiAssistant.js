Component({
  properties: {
    // 组件标题
    title: {
      type: String,
      value: 'AI助手'
    },
    // 输入框占位符
    placeholder: {
      type: String,
      value: '请输入您的问题'
    },
    // 按钮文字
    buttonText: {
      type: String,
      value: '咨询AI'
    },
    // 默认回复文字
    defaultResponse: {
      type: String,
      value: 'AI助手将在这里回答您的问题'
    },
    // DeepSeek API地址
    apiUrl: {
      type: String,
      value: 'https://api.deepseek.com/v1/chat/completions' // 替换为实际的DeepSeek API地址
    },
    // DeepSeek API密钥 (实际使用时应从安全位置获取，而不是硬编码)
    apiKey: {
      type: String,
      value: 'sk-9299c062fc0e450d9db2bbcb419bf60d' // 替换为实际的API密钥
    }
  },
  
  data: {
    question: '',
    response: '',
    isThinking: false,
    // 用户互动计数
    interactionCount: 0
  },
  
  attached() {
    // 组件初始化时设置默认回复
    this.setData({
      response: this.properties.defaultResponse
    });
    
    // 尝试从本地存储获取之前的互动次数
    const storedCount = wx.getStorageSync('aiInteractionCount');
    if (storedCount) {
      this.setData({
        interactionCount: parseInt(storedCount)
      });
    }
  },
  
  methods: {
    // 输入变化处理
    onInputChange(e) {
      this.setData({
        question: e.detail.value
      });
    },
    
    // 提交问题
    onAskAI() {
      const { question } = this.data;
      
      if (!question.trim()) {
        wx.showToast({
          title: '请输入问题',
          icon: 'none'
        });
        return;
      }
      
      // 开始思考动画
      this.setData({
        isThinking: true
      });
      
      // 检查互动次数是否已达到限制
      if (this.data.interactionCount >= 3) {
        setTimeout(() => {
          const limitReachedMessage = "墨羽书画AI探索营，请加微信交流15974148955，邮件1257381502@qq.com，谢谢你的关注，一起探讨AI的未来。";
          
          this.setData({
            response: limitReachedMessage,
            isThinking: false,
            question: ''
          });
          
          // 触发回答事件
          this.triggerEvent('response', { 
            question, 
            response: limitReachedMessage 
          });
        }, 1000);
        
        return;
      }
      
      // 调用DeepSeek API
      wx.request({
        url: this.properties.apiUrl,
        method: 'POST',
        header: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.properties.apiKey}`
        },
        data: {
          model: "deepseek-chat", // 根据DeepSeek API要求调整
          messages: [
            {
              role: "user",
              content: question
            }
          ],
          temperature: 0.7,
          max_tokens: 1000
        },
        success: (res) => {
          console.log('DeepSeek API 响应:', res);
          
          // 根据DeepSeek API的实际响应格式调整，这里假设是类似OpenAI的格式
          let aiResponse = '';
          
          // 检查响应格式并提取回复内容
          if (res.data && res.data.choices && res.data.choices.length > 0) {
            aiResponse = res.data.choices[0].message.content || '抱歉，无法获取回答。';
          } else {
            aiResponse = '抱歉，AI助手暂时无法回答您的问题。';
          }
          
          // 在回答末尾添加联系信息
          aiResponse += "\n\n墨羽书画AI探索营，请加微信交流15974148955，邮件1257381502@qq.com。";
          
          // 更新互动计数并存储
          const newCount = this.data.interactionCount + 1;
          this.setData({
            response: aiResponse,
            isThinking: false,
            question: '',
            interactionCount: newCount
          });
          
          wx.setStorageSync('aiInteractionCount', newCount);
          
          // 触发回答事件
          this.triggerEvent('response', { question, response: aiResponse });
        },
        fail: (err) => {
          console.error('API请求失败:', err);
          
          // 失败时使用备用响应
          let backupResponse = '抱歉，连接AI服务时遇到了问题。请稍后再试。';
          backupResponse += "\n\n墨羽书画AI探索营，请加微信交流15974148955，邮件1257381502@qq.com。";
          
          this.setData({
            response: backupResponse,
            isThinking: false
          });
          
          // 触发回答事件，即使是错误响应
          this.triggerEvent('response', { 
            question, 
            response: backupResponse,
            error: err
          });
        }
      });
    },
    
    // 重置互动计数（可以添加一个管理员功能使用）
    resetInteractionCount() {
      this.setData({
        interactionCount: 0
      });
      wx.setStorageSync('aiInteractionCount', 0);
    }
  }
});