Component({
  properties: {
    // 按钮文字
    text: {
      type: String,
      value: '导航按钮'
    },
    // 按钮图标（可选）
    icon: {
      type: String,
      value: ''
    },
    // 按钮颜色：red, orange, blue, green, purple
    color: {
      type: String,
      value: 'blue'
    },
    // 导航目标页面
    url: {
      type: String,
      value: ''
    }
  },
  
  data: {},
  
  methods: {
    // 点击按钮处理
    onTap() {
      const { url } = this.properties;
      if (url) {
        wx.navigateTo({
          url: url
        });
      } else {
        // 如果没有指定URL，则触发自定义事件
        this.triggerEvent('tap');
      }
    }
  }
});