// index.js - 首页逻辑
Page({
  data: {
    aiQuestion: '',
    aiResponse: 'AI助手将在这里回答您的问题',
    usageCount: 0, // 使用计数器
    // DeepSeek API配置
    apiUrl: 'https://api.deepseek.com/v1/chat/completions', // 替换为实际的API地址
    apiKey: 'sk-9299c062fc0e450d9db2bbcb419bf60d' // 替换为实际的API密钥
  },

  onLoad() {
    // 页面加载时获取使用次数
    this.updateUsageCount();
  },

  onShow() {
    // 页面显示时更新使用次数
    this.updateUsageCount();
  },

  // 更新使用次数
  updateUsageCount() {
    const count = wx.getStorageSync('aiInteractionCount') || 0;
    this.setData({
      usageCount: parseInt(count)
    });
  },

  // 处理导航
  navigateTo(e) {
    const page = e.currentTarget.dataset.page;
    wx.navigateTo({
      url: `../${page}/${page}`
    });
  },

  // 处理AI助手输入变化
  onInputChange(e) {
    this.setData({
      aiQuestion: e.detail.value
    });
  },

  // 处理AI助手问题提交
  onAskAI() {
    const { aiQuestion, apiUrl, apiKey } = this.data;
    
    if (!aiQuestion.trim()) {
      wx.showToast({
        title: '请输入问题',
        icon: 'none'
      });
      return;
    }
    
    // 获取当前互动次数
    let interactionCount = parseInt(wx.getStorageSync('aiInteractionCount') || '0');
    
    // 显示加载中
    wx.showLoading({
      title: 'AI思考中...',
    });
    
    // 检查是否达到限制
    if (interactionCount >= 3) {
      setTimeout(() => {
        wx.hideLoading();
        const limitReachedMessage = "墨羽书画AI探索营，请加微信交流15974148955，邮件1257381502@qq.com，谢谢你的关注，一起探讨AI的未来。";
        
        this.setData({
          aiResponse: limitReachedMessage,
          aiQuestion: ''
        });
      }, 1000);
      
      return;
    }
    
    // 调用DeepSeek API
    wx.request({
      url: apiUrl,
      method: 'POST',
      header: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      data: {
        model: "deepseek-chat", // 根据DeepSeek API要求调整
        messages: [
          {
            role: "user",
            content: aiQuestion
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      },
      success: (res) => {
        console.log('DeepSeek API 响应:', res);
        
        // 根据DeepSeek API的实际响应格式调整
        let aiResponse = '';
        
        if (res.data && res.data.choices && res.data.choices.length > 0) {
          aiResponse = res.data.choices[0].message.content || '抱歉，无法获取回答。';
        } else {
          aiResponse = '抱歉，AI助手暂时无法回答您的问题。';
        }
        
        // 在回答末尾添加联系信息
        aiResponse += "\n\n墨羽书画AI探索营，请加微信交流15974148955，邮件1257381502@qq.com。";
        
        // 更新互动计数并存储
        interactionCount += 1;
        wx.setStorageSync('aiInteractionCount', interactionCount);
        
        this.setData({
          aiResponse: aiResponse,
          aiQuestion: '',
          usageCount: interactionCount // 更新显示的使用次数
        });
      },
      fail: (err) => {
        console.error('API请求失败:', err);
        
        // 失败时使用备用响应
        let backupResponse = '抱歉，连接AI服务时遇到了问题。请稍后再试。';
        backupResponse += "\n\n墨羽书画AI探索营，请加微信交流15974148955，邮件1257381502@qq.com。";
        
        this.setData({
          aiResponse: backupResponse
        });
      },
      complete: () => {
        wx.hideLoading();
      }
    });
  },
  
  // 重置互动计数（可以添加管理员功能使用）
  resetUsageCount() {
    wx.setStorageSync('aiInteractionCount', 0);
    this.updateUsageCount();
  }
});