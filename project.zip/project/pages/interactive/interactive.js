Page({
  data: {
    // 图像识别
    imageUrl: '',
    imageResult: '',
    
    // 文本生成
    textPrompt: '',
    textResult: '',
    
    // 聊天机器人
    chatMessages: [
      {
        role: 'ai',
        content: '你好！我是AI助手，请问有什么我可以帮助你的吗？'
      }
    ],
    chatInput: '',
    scrollToMessage: ''
  },
  
  onLoad() {
    // 页面加载生命周期
  },
  
  // 图像识别函数
  chooseImage() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      camera: 'back',
      success: (res) => {
        this.setData({
          imageUrl: res.tempFiles[0].tempFilePath,
          imageResult: ''
        });
      }
    });
  },
  
  analyzeImage() {
    wx.showLoading({
      title: 'AI分析中...',
    });
    
    // 模拟AI分析过程
    setTimeout(() => {
      wx.hideLoading();
      
      // 模拟识别结果
      const possibleResults = [
        '识别结果：这是一张风景照片，可能是山脉或海岸线。置信度：89%',
        '识别结果：图中包含一只宠物狗，品种可能是金毛犬。置信度：92%',
        '识别结果：这是一张城市建筑照片，可能是现代化的商业区。置信度：85%',
        '识别结果：图中是一盘美食，可能是中式料理。置信度：88%'
      ];
      
      const randomIndex = Math.floor(Math.random() * possibleResults.length);
      this.setData({
        imageResult: possibleResults[randomIndex]
      });
    }, 2000);
  },
  
  resetImage() {
    this.setData({
      imageUrl: '',
      imageResult: ''
    });
  },
  
  // 文本生成函数
  onTextPromptChange(e) {
    this.setData({
      textPrompt: e.detail.value
    });
  },
  
  generateText() {
    if (!this.data.textPrompt.trim()) {
      wx.showToast({
        title: '请输入主题或开头',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({
      title: 'AI生成中...',
    });
    
    // 模拟AI生成过程
    setTimeout(() => {
      wx.hideLoading();
      
      // 根据不同的提示生成不同的文本
      let result = '';
      const prompt = this.data.textPrompt.trim().toLowerCase();
      
      if (prompt.includes('智能城市') || prompt.includes('未来城市')) {
        result = '未来的智能城市将会是人工智能与城市基础设施深度融合的产物。街道上的智能交通系统会根据实时数据自动调整信号灯，减少拥堵；建筑物配备智能能源管理系统，根据使用情况优化能源消耗；公共服务设施如垃圾桶会自动感知填满程度并通知清理；医疗、教育等公共服务也将更加智能化和个性化。这样的城市不仅提高了居民生活质量，也显著提升了资源利用效率和环境可持续性。';
      } else if (prompt.includes('教育') || prompt.includes('学习')) {
        result = 'AI驱动的个性化学习正在彻底改变教育领域。通过分析学生的学习行为、优势和弱点，AI系统能够量身定制学习内容和进度，确保每个学生都能获得最适合自己的教育体验。虚拟助教可以全天候回答学生问题，提供即时反馈，而数据分析可以帮助教师更好地了解班级整体情况和个别学生需求。这种教育模式不仅提高了学习效率，还让教育资源分配更加公平，让每个孩子的潜能都能得到充分发挥。';
      } else if (prompt.includes('医疗') || prompt.includes('健康')) {
        result = '人工智能在医疗健康领域的应用正在创造前所未有的可能性。从疾病诊断到个性化治疗方案制定，AI系统正在成为医生的得力助手。基于机器学习的影像识别技术可以发现人眼难以察觉的异常，而预测分析可以评估患者风险并制定预防措施。患者也能通过智能设备持续监测健康状况，及时发现潜在问题。这些技术的发展不仅提高了医疗质量，也使优质医疗服务变得更加普及，特别是在医疗资源有限的地区。';
      } else {
        result = '人工智能技术正在以前所未有的速度发展，改变着我们生活的方方面面。从智能手机上的语音助手到自动驾驶汽车，从个性化内容推荐到智能家居系统，AI已经深入日常生活。未来，随着技术的进一步成熟，我们将看到更多令人惊叹的应用场景。然而，这也带来了关于数据隐私、算法公平性和就业变革等重要议题。如何平衡技术创新与社会责任，将是我们共同面对的挑战。';
      }
      
      this.setData({
        textResult: result
      });
    }, 2000);
  },
  
  resetText() {
    this.setData({
      textResult: ''
    });
  },
  
  // 聊天机器人函数
  onChatInputChange(e) {
    this.setData({
      chatInput: e.detail.value
    });
  },
  
  sendChatMessage() {
    const { chatInput, chatMessages } = this.data;
    
    if (!chatInput.trim()) {
      return;
    }
    
    // 添加用户消息
    const updatedMessages = [...chatMessages, {
      role: 'user',
      content: chatInput
    }];
    
    this.setData({
      chatMessages: updatedMessages,
      chatInput: '',
      scrollToMessage: `msg-${updatedMessages.length - 1}`
    });
    
    // 模拟AI思考时间
    setTimeout(() => {
      // 根据用户输入生成AI回复
      let aiResponse = '';
      const userInput = chatInput.toLowerCase();
      
      if (userInput.includes('你好') || userInput.includes('hi') || userInput.includes('hello')) {
        aiResponse = '你好！很高兴和你交流。有什么我可以帮助你的吗？';
      } else if (userInput.includes('你是谁') || userInput.includes('你的名字') || userInput.includes('介绍')) {
        aiResponse = '我是墨羽书画AI探索营的智能助手，我可以回答关于AI的问题，或者与你进行日常对话。';
      } else if (userInput.includes('人工智能') || userInput.includes('ai') || userInput.includes('机器学习')) {
        aiResponse = '人工智能是计算机科学的一个分支，致力于创造能够模拟人类智能的系统。机器学习是AI的一个重要子领域，它使计算机能够从数据中学习而无需明确编程。如果你想了解更多，可以查看我们的"AI基础概念"章节。';
      } else if (userInput.includes('谢谢') || userInput.includes('感谢')) {
        aiResponse = '不客气！如果还有其他问题，随时问我。';
      } else {
        aiResponse = '这是个很有趣的问题。作为AI助手，我正在学习和成长中。你可以继续探索我们的互动实验，或者查看其他章节了解更多AI相关知识。';
      }
      
      // 添加AI回复
      const finalMessages = [...this.data.chatMessages, {
        role: 'ai',
        content: aiResponse
      }];
      
      this.setData({
        chatMessages: finalMessages,
        scrollToMessage: `msg-${finalMessages.length - 1}`
      });
    }, 1000);
  },
  
  // 导航函数
  navigateBack() {
    wx.navigateBack();
  },
  
  navigateToNext() {
    wx.navigateTo({
      url: '../programmingBasics/programmingBasics'
    });
  }
});