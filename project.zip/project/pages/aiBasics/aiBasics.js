Page({
  data: {
    selectedOption: '',
    showResult: false,
    quizResult: ''
  },
  
  onLoad() {
    // 页面加载生命周期
  },
  
  // 测验选项选择处理器
  selectOption(e) {
    const option = e.currentTarget.dataset.option;
    this.setData({
      selectedOption: option,
      showResult: false
    });
  },
  
  // 测验答案检查处理器
  checkAnswer() {
    if (!this.data.selectedOption) {
      wx.showToast({
        title: '请选择一个选项',
        icon: 'none'
      });
      return;
    }
    
    // 检查答案
    if (this.data.selectedOption === 'B') {
      this.setData({
        showResult: true,
        quizResult: '答对了！图灵测试是由艾伦·图灵在1950年提出的，目的是测试机器能否像人类一样思考。'
      });
    } else {
      this.setData({
        showResult: true,
        quizResult: '答错了，正确答案是B. 图灵测试目的是测试计算机的智能是否能与人类相媲美。'
      });
    }
  },
  
  // 导航处理器
  navigateBack() {
    wx.navigateBack();
  },
  
  navigateToNext() {
    wx.navigateTo({
      url: '../aiApplications/aiApplications'
    });
  }
});