Page({
  data: {
    currentTab: 0,
    
    // 练习1
    exercise1Code: '',
    exercise1Result: '',
    showExercise1Hint: false,
    
    // 练习2
    exercise2Code: '',
    exercise2Result: '',
    showExercise2Hint: false
  },
  
  onLoad() {
    // 页面加载生命周期
  },
  
  // 切换标签页
  switchTab(e) {
    const tab = parseInt(e.currentTarget.dataset.tab);
    this.setData({
      currentTab: tab
    });
  },
  
  // 练习1代码输入
  onExercise1Input(e) {
    this.setData({
      exercise1Code: e.detail.value
    });
  },
  
  // 练习2代码输入
  onExercise2Input(e) {
    this.setData({
      exercise2Code: e.detail.value
    });
  },
  
  // 显示提示
  showHint(e) {
    const exercise = e.currentTarget.dataset.exercise;
    if (exercise === '1') {
      this.setData({
        showExercise1Hint: !this.data.showExercise1Hint
      });
    } else if (exercise === '2') {
      this.setData({
        showExercise2Hint: !this.data.showExercise2Hint
      });
    }
  },
  
  // 运行代码
  runExercise(e) {
    const exercise = e.currentTarget.dataset.exercise;
    
    if (exercise === '1') {
      const code = this.data.exercise1Code.trim();
      if (!code) {
        wx.showToast({
          title: '请编写代码',
          icon: 'none'
        });
        return;
      }
      
      // 简单的代码评估逻辑
      let result = '';
      if (code.includes('def') && code.includes('return') && 
          (code.includes('sum') || code.includes('for') || code.includes('while'))) {
        
        // 模拟测试用例
        result = '✅ 测试通过!\n\n';
        result += '测试用例1: [1, 2, 3, 4, 5]\n';
        result += '预期结果: 3.0\n';
        result += '你的结果: 3.0\n\n';
        
        result += '测试用例2: [10, 20, 30, 40]\n';
        result += '预期结果: 25.0\n';
        result += '你的结果: 25.0';
      } else {
        result = '❌ 测试失败\n\n';
        result += '请确保你的代码:\n';
        result += '- 定义了一个函数\n';
        result += '- 计算了列表中所有数字的总和\n';
        result += '- 返回了正确的平均值';
      }
      
      this.setData({
        exercise1Result: result
      });
    } else if (exercise === '2') {
      const code = this.data.exercise2Code.trim();
      if (!code) {
        wx.showToast({
          title: '请编写代码',
          icon: 'none'
        });
        return;
      }
      
      // 简单的代码评估逻辑
      let result = '';
      if (code.includes('def') && code.includes('return') && 
          code.includes('for') && (code.includes('%') || code.includes('mod'))) {
        
        // 模拟测试用例
        result = '✅ 测试通过!\n\n';
        result += '测试用例1: 7\n';
        result += '预期结果: True\n';
        result += '你的结果: True\n\n';
        
        result += '测试用例2: 4\n';
        result += '预期结果: False\n';
        result += '你的结果: False\n\n';
        
        result += '测试用例3: 1\n';
        result += '预期结果: False\n';
        result += '你的结果: False';
      } else {
        result = '❌ 测试失败\n\n';
        result += '请确保你的代码:\n';
        result += '- 定义了一个函数\n';
        result += '- 正确处理了边界情况(如1)\n';
        result += '- 检查了所有可能的约数\n';
        result += '- 返回了正确的布尔结果';
      }
      
      this.setData({
        exercise2Result: result
      });
    }
  },
  
  // 导航函数
  navigateBack() {
    wx.navigateBack();
  },
  
  navigateToNext() {
    wx.navigateTo({
      url: '../aiModelDemo/aiModelDemo'
    });
  }
});