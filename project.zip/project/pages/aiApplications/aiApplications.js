Page({
  data: {
    showModal: false,
    currentApplication: {},
    applications: [
      {
        title: 'AI艺术创作',
        image: '/images/ai-art.jpg',
        description: 'AI艺术创作利用生成式AI模型，如GAN、扩散模型等，根据文本提示或参考图像创建全新的艺术作品。这一技术已经在艺术、设计、广告等领域得到广泛应用，为创作者提供了全新的创意工具。',
        useCases: [
          {
            title: '数字艺术创作',
            description: '艺术家使用AI生成创意灵感或直接创作艺术品'
          },
          {
            title: '品牌视觉设计',
            description: '快速生成符合品牌调性的视觉素材与创意'
          },
          {
            title: '游戏与影视素材',
            description: '生成游戏场景、角色设计与电影概念艺术'
          }
        ],
        technologies: ['生成对抗网络(GAN)', '扩散模型', 'CLIP', 'Transformer架构']
      },
      {
        title: 'AI医疗诊断',
        image: '/images/ai-medicine.jpg',
        description: 'AI医疗诊断系统利用深度学习算法分析医学影像、病历数据和生物标志物，帮助医生更准确地诊断疾病、预测病情发展和制定个性化治疗方案。这些系统能够识别人眼难以察觉的细微异常，提高早期诊断率。',
        useCases: [
          {
            title: '医学影像分析',
            description: '辅助分析X光片、CT、MRI等医学影像，检测异常'
          },
          {
            title: '疾病风险预测',
            description: '基于患者数据预测特定疾病风险与发展趋势'
          },
          {
            title: '药物研发加速',
            description: '加速新药筛选与开发流程，降低研发成本'
          }
        ],
        technologies: ['深度学习', '计算机视觉', '自然语言处理', '知识图谱']
      },
      {
        title: 'AI教育辅助',
        image: '/images/ai-education.jpg',
        description: 'AI教育辅助系统通过分析学生的学习行为、成绩表现和知识掌握程度，提供个性化的学习路径和内容推荐。这些系统能够自动识别学生的知识盲点，并提供针对性的练习和反馈，同时减轻教师的日常工作负担。',
        useCases: [
          {
            title: '个性化学习路径',
            description: '根据学生能力与进度自动调整学习内容与难度'
          },
          {
            title: '智能作业批改',
            description: '自动批改作业并提供详细反馈，节省教师时间'
          },
          {
            title: '学习行为分析',
            description: '分析学习模式，识别知识盲点，预测学习成果'
          }
        ],
        technologies: ['机器学习', '自然语言处理', '知识追踪', '推荐系统']
      },
      {
        title: 'AI智能制造',
        image: '/images/ai-manufacturing.jpg',
        description: 'AI智能制造系统将机器学习与工业物联网相结合，实现生产过程的智能化管理。这些系统可以预测设备故障、优化生产计划、自动检测产品缺陷，从而提高生产效率、降低能耗和维护成本，同时保证产品质量的一致性。',
        useCases: [
          {
            title: '预测性维护',
            description: '预测设备故障，安排最佳维护时间，减少停机'
          },
          {
            title: '质量控制',
            description: '自动检测产品缺陷，确保产品质量一致性'
          },
          {
            title: '供应链优化',
            description: '预测需求波动，优化库存管理与物流配送'
          }
        ],
        technologies: ['工业物联网', '机器视觉', '时间序列分析', '强化学习']
      }
    ],
    successStories: [
      {
        company: '阿里巴巴',
        title: 'AI客服系统升级',
        content: '阿里巴巴通过部署大规模AI客服系统，实现了24小时无间断智能客服支持，系统能够理解复杂的客户问题并提供精准解答。',
        result: '客服响应时间减少65%，客户满意度提升23%'
      },
      {
        company: '腾讯',
        title: '游戏AI助手',
        content: '腾讯在多款游戏中引入AI助手系统，为玩家提供实时游戏建议、自动匹配合适对手，并识别作弊行为。',
        result: '玩家留存率提高30%，游戏体验评分上升18%'
      },
      {
        company: '华为',
        title: '智能手机摄影系统',
        content: '华为在旗舰手机中集成AI摄影系统，能够识别场景、优化参数、提升暗光效果，让普通用户也能拍出专业级照片。',
        result: '用户拍摄频率增加40%，社交媒体分享率提升50%'
      }
    ]
  },
  
  onLoad() {
    // 页面加载生命周期
  },
  
  // 显示应用详情
  showApplicationDetail(e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      showModal: true,
      currentApplication: this.data.applications[index]
    });
  },
  
  // 隐藏模态框
  hideModal() {
    this.setData({
      showModal: false
    });
  },
  
  // 导航处理函数
  navigateBack() {
    wx.navigateBack();
  },
  
  navigateToNext() {
    wx.navigateTo({
      url: '../interactive/interactive'
    });
  }
});